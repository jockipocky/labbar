#include <stdint.h>
#include <pic32mx.h>
#include "mipslab.h"

// Function for input switches 
int getsw (void){

return (PORTD >> 8) & 0xf; // Shift right 8 bits and then mask 4 lsb

}
// Function for input buttons
int getbtns(void){

return(PORTD >> 5) & 0x7; // Shift right 5 bits and the mask 3 lsb

}


